(function () {
  "use strict";
  var $ = function (s) { return document.querySelector(s); };
  var C = 2 * Math.PI * 146;
  var STEP = 0.25, MIN_M = 0.25, MAX_M = 4;
  var LOG_KEY = "plate-log-v1";

  var el = {
    plate: $("#plate"), photo: $("#photo"), go: $("#go"), stop: $("#stop"), note: $("#note"),
    status: $("#status"), hint: $("#consent-hint"),
    camBtn: $("#btn-camera"), chooseBtn: $("#btn-choose"), camIn: $("#file-camera"), chooseIn: $("#file-choose"),
    placeholder: $("#placeholder"), result: $("#result"), itemsPanel: $("#items-panel"),
    dish: $("#dish"), kcal: $("#kcal"), range: $("#range"), mp: $("#m-p"), mc: $("#m-c"), mf: $("#m-f"),
    items: $("#items"), conf: $("#confidence"), save: $("#save"),
    logs: $("#logs"), logTotal: $("#log-total"), logEmpty: $("#log-empty"),
    segs: [$("#seg-p"), $("#seg-c"), $("#seg-f")]
  };

  var ENDPOINT = (window.PLATE_CONFIG && window.PLATE_CONFIG.endpoint) || "";
  var ready = false;
  var state = { blob: null, dataUrl: null, items: [], lowRatio: 0.85, highRatio: 1.2, dish: "", ctl: null, timer: null, saved: false };

  /* ---------- helpers ---------- */
  function num(x) { var n = Number(x); return isFinite(n) && n >= 0 ? n : 0; }
  function round5(n) { return Math.round(n / 5) * 5; }
  function fmt(n) { return Math.round(n).toLocaleString(); }
  function setStatus(msg, isError) { el.status.textContent = msg || ""; el.status.className = isError ? "error" : ""; }
  function resetSegs() { el.segs.forEach(function (s) { s.style.strokeDasharray = "0 " + C; s.style.strokeDashoffset = "0"; }); }
  resetSegs();

  /* ---------- Claude capability ---------- */
  function initSample() {
    ready = /^https?:\/\//.test(ENDPOINT) && ENDPOINT.indexOf("YOUR-") === -1;
    if (!ready) {
      setStatus("Photo analysis isn't set up yet. Add your API address to config.js.", true);
      el.hint.hidden = true;
    }
    refreshGo();
  }

  function refreshGo() {
    el.go.disabled = !(ready && state.blob) || !!state.ctl;
  }

  /* ---------- photo handling ---------- */
  async function decode(file) {
    try { return await createImageBitmap(file, { imageOrientation: "from-image" }); }
    catch (e) { return await createImageBitmap(file); }
  }

  async function setFile(file) {
    if (!file) return;
    if (!/^image\//.test(file.type)) { setStatus("That file isn't a photo. Choose a JPEG or PNG image.", true); return; }
    try {
      var bmp = await decode(file);
      var max = 1280, scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
      var w = Math.max(1, Math.round(bmp.width * scale)), h = Math.max(1, Math.round(bmp.height * scale));
      var cv = document.createElement("canvas");
      cv.width = w; cv.height = h;
      cv.getContext("2d").drawImage(bmp, 0, 0, w, h);
      if (bmp.close) bmp.close();
      var blob = await new Promise(function (res) { cv.toBlob(res, "image/jpeg", 0.86); });
      if (!blob) throw new Error("encode");
      state.blob = blob;
      state.dataUrl = cv.toDataURL("image/jpeg", 0.8);
    } catch (e) {
      setStatus("That photo couldn't be read. Try a JPEG or PNG.", true);
      return;
    }
    el.photo.setAttribute("href", state.dataUrl);
    el.plate.classList.remove("empty");
    clearResult();
    setStatus(ready ? "Photo ready. Press Estimate calories." : el.status.textContent, !ready);
    refreshGo();
  }

  function clearResult() {
    state.items = [];
    resetSegs();
    el.result.hidden = true;
    el.itemsPanel.hidden = true;
    el.placeholder.hidden = false;
  }

  el.camBtn.addEventListener("click", function () { el.camIn.click(); });
  el.chooseBtn.addEventListener("click", function () { el.chooseIn.click(); });
  [el.camIn, el.chooseIn].forEach(function (inp) {
    inp.addEventListener("change", function () { var f = inp.files && inp.files[0]; inp.value = ""; setFile(f); });
  });
  ["dragenter", "dragover"].forEach(function (ev) {
    el.plate.addEventListener(ev, function (e) { e.preventDefault(); el.plate.classList.add("drag"); });
  });
  ["dragleave", "drop"].forEach(function (ev) {
    el.plate.addEventListener(ev, function (e) { e.preventDefault(); el.plate.classList.remove("drag"); });
  });
  el.plate.addEventListener("drop", function (e) {
    var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    setFile(f);
  });
  document.addEventListener("paste", function (e) {
    var files = e.clipboardData && e.clipboardData.files;
    if (!files) return;
    for (var i = 0; i < files.length; i++) { if (/^image\//.test(files[i].type)) { setFile(files[i]); break; } }
  });

  /* ---------- analysis ---------- */
  var MESSAGES = ["Looking at your plate…", "Identifying each food…", "Judging portion sizes…", "Adding up calories…"];

  function setBusy(on) {
    el.plate.classList.toggle("busy", on);
    el.stop.hidden = !on;
    el.camBtn.disabled = el.chooseBtn.disabled = on;
    clearInterval(state.timer);
    if (on) {
      var i = 0;
      setStatus(MESSAGES[0]);
      state.timer = setInterval(function () { i = Math.min(i + 1, MESSAGES.length - 1); setStatus(MESSAGES[i]); }, 4000);
    }
    refreshGo();
  }

  var ERRORS = {
    rate_limited: "Too many requests right now. Wait a minute, then try again.",
    too_large: "That photo is too large. Try a smaller one.",
    bad_image: "That photo couldn't be read. Try a JPEG or PNG.",
    origin_not_allowed: "This site isn't allowed to use the estimate service. The site owner needs to add its address to ALLOWED_ORIGINS.",
    server_misconfigured: "The estimate service isn't set up correctly. The site owner needs to add the API key.",
    upstream_error: "The estimate service is busy. Try again in a moment."
  };

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result).split(",")[1] || ""); };
      r.onerror = function () { reject({ code: "bad_image" }); };
      r.readAsDataURL(blob);
    });
  }

  async function analyze() {
    if (!ready || !state.blob || state.ctl) return;
    state.ctl = new AbortController();
    setBusy(true);
    var note = el.note.value.trim().slice(0, 300);
    try {
      var image = await blobToBase64(state.blob);
      var res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: image, note: note }),
        signal: state.ctl.signal
      });
      var data = null;
      try { data = await res.json(); } catch (e) { data = null; }
      if (!res.ok) throw { code: (data && data.error) || "http_" + res.status };
      applyResult(data);
    } catch (e) {
      if (e && e.name === "AbortError") { setStatus("Stopped."); }
      else {
        clearResult();
        setStatus(ERRORS[e && e.code] || "Couldn't get a readable estimate. Check your connection, then try again with a clearer photo taken from above.", true);
      }
    } finally {
      state.ctl = null;
      setBusy(false);
    }
  }

  function applyResult(d) {
    if (!d || typeof d !== "object") throw { code: "invalid_json" };
    if (d.is_food === false) {
      clearResult();
      setStatus(typeof d.message === "string" && d.message ? "That doesn't look like food: " + d.message.slice(0, 160) : "That doesn't look like a photo of food. Try another photo.", true);
      return;
    }
    var raw = Array.isArray(d.items) ? d.items.slice(0, 12) : [];
    var items = raw.map(function (it) {
      return {
        name: String(it && it.name || "Food").slice(0, 80),
        portion: String(it && it.portion || "").slice(0, 80),
        calories: num(it && it.calories), protein: num(it && it.protein_g),
        carbs: num(it && it.carbs_g), fat: num(it && it.fat_g),
        m: 1, on: true
      };
    }).filter(function (it) { return it.name; });
    if (!items.length) throw { code: "invalid_json" };

    var base = items.reduce(function (a, it) { return a + it.calories; }, 0);
    var lo = num(d.total_low), hi = num(d.total_high);
    state.lowRatio = base > 0 && lo > 0 ? Math.min(1, Math.max(0.5, lo / base)) : 0.85;
    state.highRatio = base > 0 && hi > 0 ? Math.max(1, Math.min(2, hi / base)) : 1.2;
    state.items = items;
    state.dish = String(d.dish || "Meal").slice(0, 80);
    state.saved = false;

    el.dish.textContent = state.dish;
    var conf = ["low", "medium", "high"].indexOf(d.confidence) >= 0 ? d.confidence : "medium";
    el.conf.textContent = "Confidence: " + conf + "." + (d.tip ? " " + String(d.tip).slice(0, 220) : "");
    buildItems();
    el.placeholder.hidden = true;
    el.result.hidden = false;
    el.itemsPanel.hidden = false;
    setStatus("Done. Adjust anything that looks off.");
    resetSegs();
    requestAnimationFrame(function () { requestAnimationFrame(updateTotals); });
    el.save.textContent = "Save to today's log";
    el.save.disabled = false;
  }

  /* ---------- items list ---------- */
  function buildItems() {
    el.items.textContent = "";
    state.items.forEach(function (it, i) {
      var li = document.createElement("li");
      li.className = "item";

      var cb = document.createElement("input");
      cb.type = "checkbox"; cb.checked = true; cb.id = "on-" + i;
      cb.setAttribute("aria-label", "Include " + it.name);
      cb.addEventListener("change", function () { it.on = cb.checked; markEdited(); updateTotals(); });

      var mid = document.createElement("div"); mid.className = "mid";
      var name = document.createElement("div"); name.className = "name"; name.textContent = it.name;
      var meta = document.createElement("div"); meta.className = "meta";
      mid.appendChild(name); mid.appendChild(meta);

      var cal = document.createElement("div"); cal.className = "cal";

      var st = document.createElement("div"); st.className = "stepper";
      var lbl = document.createElement("span"); lbl.className = "lbl"; lbl.textContent = "Portion";
      var dec = document.createElement("button"); dec.type = "button"; dec.textContent = "−"; dec.setAttribute("aria-label", "Smaller portion of " + it.name);
      var out = document.createElement("output"); out.setAttribute("aria-live", "polite");
      var inc = document.createElement("button"); inc.type = "button"; inc.textContent = "+"; inc.setAttribute("aria-label", "Bigger portion of " + it.name);
      dec.addEventListener("click", function () { it.m = Math.max(MIN_M, +(it.m - STEP).toFixed(2)); markEdited(); updateTotals(); });
      inc.addEventListener("click", function () { it.m = Math.min(MAX_M, +(it.m + STEP).toFixed(2)); markEdited(); updateTotals(); });
      st.appendChild(lbl); st.appendChild(dec); st.appendChild(out); st.appendChild(inc);

      li.appendChild(cb); li.appendChild(mid); li.appendChild(cal); li.appendChild(st);
      el.items.appendChild(li);
      it.ui = { li: li, meta: meta, cal: cal, out: out, dec: dec, inc: inc };
    });
  }

  function markEdited() {
    if (state.saved) { state.saved = false; el.save.textContent = "Save to today's log"; el.save.disabled = false; }
  }

  function totals() {
    var t = { cal: 0, p: 0, c: 0, f: 0 };
    state.items.forEach(function (it) {
      if (!it.on) return;
      t.cal += it.calories * it.m; t.p += it.protein * it.m; t.c += it.carbs * it.m; t.f += it.fat * it.m;
    });
    return t;
  }

  function updateTotals() {
    state.items.forEach(function (it) {
      var u = it.ui; if (!u) return;
      u.li.classList.toggle("off", !it.on);
      u.cal.textContent = fmt(round5(it.calories * it.m)) + " kcal";
      var portion = it.portion ? it.portion : "";
      var scaled = it.m === 1 ? "" : " × " + it.m;
      u.meta.textContent = (portion + scaled).trim() + (portion || scaled ? ". " : "") +
        fmt(it.protein * it.m) + " g protein, " + fmt(it.carbs * it.m) + " g carbs, " + fmt(it.fat * it.m) + " g fat";
      u.out.textContent = "×" + it.m;
      u.dec.disabled = it.m <= MIN_M; u.inc.disabled = it.m >= MAX_M;
    });
    var t = totals();
    el.kcal.textContent = fmt(round5(t.cal));
    if (t.cal > 0) {
      el.range.textContent = "Likely between " + fmt(round5(t.cal * state.lowRatio)) + " and " + fmt(round5(t.cal * state.highRatio)) + " kcal";
    } else { el.range.textContent = "No foods included."; }
    el.mp.textContent = fmt(t.p) + " g"; el.mc.textContent = fmt(t.c) + " g"; el.mf.textContent = fmt(t.f) + " g";

    var kc = [t.p * 4, t.c * 4, t.f * 9], sum = kc[0] + kc[1] + kc[2], start = 0;
    el.segs.forEach(function (s, i) {
      var frac = sum > 0 ? kc[i] / sum : 0;
      var gap = frac > 0 && frac < 1 ? 5 : 0;
      var len = Math.max(0, frac * C - gap);
      s.style.strokeDasharray = len + " " + (C - len);
      s.style.strokeDashoffset = String(-start);
      start += frac * C;
    });
  }

  /* ---------- daily log ---------- */
  var log = [];
  try { log = JSON.parse(localStorage.getItem(LOG_KEY) || "[]"); if (!Array.isArray(log)) log = []; } catch (e) { log = []; }
  function persist() { try { localStorage.setItem(LOG_KEY, JSON.stringify(log.slice(-4000))); } catch (e) { /* keep in memory only */ } }
  function dayKey(d) { return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }

  function renderLog() {
    var today = dayKey(new Date());
    var mine = log.filter(function (e) { return e && e.day === today; });
    el.logs.textContent = "";
    var total = 0;
    mine.forEach(function (e) {
      total += num(e.kcal);
      var li = document.createElement("li");
      var left = document.createElement("div");
      var nm = document.createElement("div"); nm.textContent = String(e.dish || "Meal");
      var tm = document.createElement("div"); tm.className = "t"; tm.textContent = new Date(e.ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      left.appendChild(nm); left.appendChild(tm);
      var k = document.createElement("span"); k.className = "k"; k.textContent = fmt(num(e.kcal)) + " kcal";
      var rm = document.createElement("button"); rm.type = "button"; rm.className = "btn small ghost"; rm.textContent = "Remove";
      rm.setAttribute("aria-label", "Remove " + String(e.dish || "meal") + " from today's log");
      rm.addEventListener("click", function () { log = log.filter(function (x) { return x !== e; }); persist(); renderLog(); });
      li.appendChild(left); li.appendChild(k); li.appendChild(rm);
      el.logs.appendChild(li);
    });
    el.logTotal.textContent = fmt(total) + " kcal";
    el.logEmpty.hidden = mine.length > 0;
    renderYear();
  }

  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  var MONTH_FULL = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  var DOW = ["S", "M", "T", "W", "T", "F", "S"];
  var DOW_LONG = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var cal = { view: "month", y: new Date().getFullYear(), m: new Date().getMonth(), sel: null };

  function keyOf(y, m, d) { return y + "-" + (m + 1) + "-" + d; }
  function tint(v, max) {
    var pct = Math.round(8 + 27 * (v / (max || 1)));
    return "color-mix(in srgb, var(--brand) " + pct + "%, transparent)";
  }

  function step(dir) {
    if (cal.view === "month") {
      cal.m += dir;
      if (cal.m < 0) { cal.m = 11; cal.y--; }
      if (cal.m > 11) { cal.m = 0; cal.y++; }
    } else { cal.y += dir; }
    renderYear();
  }
  $("#cal-prev").addEventListener("click", function () { step(-1); });
  $("#cal-next").addEventListener("click", function () { step(1); });
  $("#cal-today").addEventListener("click", function () {
    var n = new Date(); cal.y = n.getFullYear(); cal.m = n.getMonth(); cal.sel = keyOf(cal.y, cal.m, n.getDate()); renderYear();
  });
  $("#v-month").addEventListener("click", function () { cal.view = "month"; renderYear(); });
  $("#v-year").addEventListener("click", function () { cal.view = "year"; renderYear(); });

  function renderYear() {
    var now = new Date(), cy = now.getFullYear();
    var todayMid = new Date(cy, now.getMonth(), now.getDate());
    var todayKey = keyOf(cy, now.getMonth(), now.getDate());
    var totalDays = Math.round((new Date(cy + 1, 0, 1) - new Date(cy, 0, 1)) / 86400000);
    var doy = Math.round((todayMid - new Date(cy, 0, 1)) / 86400000) + 1;
    var pct = Math.round(doy / totalDays * 100);
    $("#year-fill").style.width = (doy / totalDays * 100) + "%";
    $("#year-bar").setAttribute("aria-valuenow", String(pct));
    $("#year-text").textContent = cy + ": day " + doy + " of " + totalDays + ", " + pct + "% of the year";

    var byDay = {}, max = 0;
    log.forEach(function (e) { if (e && e.day) byDay[e.day] = (byDay[e.day] || 0) + num(e.kcal); });
    Object.keys(byDay).forEach(function (k) { if (byDay[k] > max) max = byDay[k]; });

    $("#v-month").setAttribute("aria-pressed", String(cal.view === "month"));
    $("#v-year").setAttribute("aria-pressed", String(cal.view === "year"));
    $("#cal-label").textContent = cal.view === "month" ? MONTH_FULL[cal.m] + " " + cal.y : String(cal.y);
    $("#cal-prev").setAttribute("aria-label", cal.view === "month" ? "Previous month" : "Previous year");
    $("#cal-next").setAttribute("aria-label", cal.view === "month" ? "Next month" : "Next year");

    var host = $("#cal");
    host.textContent = "";

    if (cal.view === "month") {
      var dow = document.createElement("div"); dow.className = "dow"; dow.setAttribute("aria-hidden", "true");
      DOW.forEach(function (l) { var sp = document.createElement("span"); sp.textContent = l; dow.appendChild(sp); });
      host.appendChild(dow);
      var days = document.createElement("div"); days.className = "days";
      var first = new Date(cal.y, cal.m, 1).getDay();
      var dim = new Date(cal.y, cal.m + 1, 0).getDate();
      for (var b = 0; b < first; b++) { var bl = document.createElement("div"); bl.className = "blank"; days.appendChild(bl); }
      for (var d = 1; d <= dim; d++) {
        (function (d) {
          var key = keyOf(cal.y, cal.m, d), v = byDay[key];
          var date = new Date(cal.y, cal.m, d);
          var btn = document.createElement("button");
          btn.type = "button"; btn.className = "day";
          if (date > todayMid) btn.className += " future";
          if (key === todayKey) btn.className += " today";
          if (key === cal.sel) btn.className += " sel";
          var n = document.createElement("span"); n.className = "n"; n.textContent = String(d);
          var k = document.createElement("span"); k.className = "k"; k.textContent = v ? fmt(v) : "";
          if (v) btn.style.background = tint(v, max);
          btn.appendChild(n); btn.appendChild(k);
          btn.setAttribute("aria-label", DOW_LONG[date.getDay()] + " " + MONTH_FULL[cal.m] + " " + d + (v ? ", " + fmt(v) + " kcal logged" : ", nothing logged"));
          btn.setAttribute("aria-pressed", String(key === cal.sel));
          btn.addEventListener("click", function () { cal.sel = key; renderYear(); });
          days.appendChild(btn);
        })(d);
      }
      host.appendChild(days);
    } else {
      var months = document.createElement("div"); months.className = "months";
      for (var mo = 0; mo < 12; mo++) {
        (function (mo) {
          var mini = document.createElement("div"); mini.className = "mini";
          var nm = document.createElement("button"); nm.type = "button"; nm.className = "mname"; nm.textContent = MONTH_FULL[mo];
          nm.setAttribute("aria-label", "Open " + MONTH_FULL[mo] + " " + cal.y);
          nm.addEventListener("click", function () { cal.view = "month"; cal.m = mo; renderYear(); });
          mini.appendChild(nm);
          var grid = document.createElement("div"); grid.className = "days";
          var f = new Date(cal.y, mo, 1).getDay(), dm = new Date(cal.y, mo + 1, 0).getDate();
          for (var i = 0; i < f; i++) { var e = document.createElement("div"); e.className = "blank"; grid.appendChild(e); }
          for (var dd = 1; dd <= dm; dd++) {
            (function (dd) {
              var key = keyOf(cal.y, mo, dd), v = byDay[key], date = new Date(cal.y, mo, dd);
              var c = document.createElement("button"); c.type = "button"; c.className = "mday";
              if (date > todayMid) c.className += " future";
              if (key === todayKey) c.className += " today";
              c.textContent = String(dd);
              if (v) c.style.background = tint(v, max);
              c.setAttribute("aria-label", MONTH_FULL[mo] + " " + dd + (v ? ", " + fmt(v) + " kcal logged" : ", nothing logged"));
              c.title = MONTHS[mo] + " " + dd + (v ? ": " + fmt(v) + " kcal" : "");
              c.addEventListener("click", function () { cal.view = "month"; cal.m = mo; cal.sel = key; renderYear(); });
              grid.appendChild(c);
            })(dd);
          }
          mini.appendChild(grid);
          months.appendChild(mini);
        })(mo);
      }
      host.appendChild(months);
    }

    // Selected day detail
    var det = $("#day-detail");
    det.textContent = "";
    if (cal.sel) {
      var mine = log.filter(function (e) { return e && e.day === cal.sel; });
      var parts = cal.sel.split("-").map(Number);
      var sd = new Date(parts[0], parts[1] - 1, parts[2]);
      var tot = mine.reduce(function (a, e) { return a + num(e.kcal); }, 0);
      var h = document.createElement("h3");
      h.textContent = DOW_LONG[sd.getDay()] + ", " + MONTHS[sd.getMonth()] + " " + sd.getDate() + (mine.length ? ": " + fmt(tot) + " kcal" : "");
      det.appendChild(h);
      if (!mine.length) {
        var none = document.createElement("p"); none.className = "sub"; none.textContent = "Nothing logged on this day."; det.appendChild(none);
      } else {
        var ul = document.createElement("ul"); ul.className = "logs";
        mine.forEach(function (e) {
          var li = document.createElement("li");
          var left = document.createElement("div");
          var nm2 = document.createElement("div"); nm2.textContent = String(e.dish || "Meal");
          var tm = document.createElement("div"); tm.className = "t"; tm.textContent = new Date(e.ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
          left.appendChild(nm2); left.appendChild(tm);
          var kk = document.createElement("span"); kk.className = "k"; kk.textContent = fmt(num(e.kcal)) + " kcal";
          var rm = document.createElement("button"); rm.type = "button"; rm.className = "btn small ghost"; rm.textContent = "Remove";
          rm.setAttribute("aria-label", "Remove " + String(e.dish || "meal") + " from this day");
          rm.addEventListener("click", function () { log = log.filter(function (x) { return x !== e; }); persist(); renderLog(); });
          li.appendChild(left); li.appendChild(kk); li.appendChild(rm);
          ul.appendChild(li);
        });
        det.appendChild(ul);
      }
      det.hidden = false;
    } else { det.hidden = true; }

    // Stats for the current year
    var logged = 0, sum = 0;
    Object.keys(byDay).forEach(function (k) { if (k.indexOf(cy + "-") === 0) { logged++; sum += byDay[k]; } });
    $("#year-stats").textContent = logged
      ? logged + (logged === 1 ? " day" : " days") + " logged in " + cy + ", averaging " + fmt(sum / logged) + " kcal. Darker days have more calories."
      : "Save meals and the days you log fill in here. Tap a day to see what you ate.";
  }

  el.save.addEventListener("click", function () {
    var t = totals();
    if (t.cal <= 0) { setStatus("Include at least one food before saving.", true); return; }
    var now = new Date();
    log.push({ day: dayKey(now), ts: now.getTime(), dish: state.dish, kcal: round5(t.cal) });
    persist(); renderLog();
    state.saved = true;
    el.save.textContent = "Saved";
    el.save.disabled = true;
    setStatus("Saved to today's log.");
  });

  /* ---------- wiring ---------- */
  el.go.addEventListener("click", analyze);
  el.stop.addEventListener("click", function () { if (state.ctl) state.ctl.abort(); });
  el.note.addEventListener("keydown", function (e) { if (e.key === "Enter" && !el.go.disabled) analyze(); });

  renderLog();
  initSample();
})();
