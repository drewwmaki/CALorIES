# What's on your plate?

Take a photo of a meal and get a calorie and macro estimate, with an editable food list, a daily log, and a year calendar. Your log is saved in your own browser.

The website is static files hosted free on **GitHub Pages**. Because the photo analysis uses the Claude API, a tiny **Cloudflare Worker** sits in between so your API key stays secret.

```
Browser (GitHub Pages)  ->  Cloudflare Worker (holds API key)  ->  Claude API
```

## Files

| File | What it is |
| --- | --- |
| `index.html`, `styles.css`, `app.js` | The website |
| `config.js` | Where you paste your worker's address |
| `worker/worker.js`, `worker/wrangler.toml` | The secure go-between |
| `.github/workflows/pages.yml` | Publishes the site to GitHub Pages on every push |

## Setup (about 15 minutes)

### 1. Get an Anthropic API key
Create one at https://console.anthropic.com. Set a monthly spend limit on it so a surprise can't cost you much.

### 2. Put the code on GitHub
1. Create a new repository on GitHub (public is fine, there are no secrets in these files).
2. Upload everything in this folder, keeping the folder structure (including the hidden `.github` folder).
3. In the repo go to **Settings > Pages** and set **Source** to **GitHub Actions**.

Your site address will be `https://YOUR-USERNAME.github.io/YOUR-REPO/`.

### 3. Deploy the worker
You need Node.js installed.

```bash
cd worker
npm install -g wrangler
wrangler login
```

Open `wrangler.toml` and set `ALLOWED_ORIGINS` to `https://YOUR-USERNAME.github.io` (the address only, no repo name, no trailing slash). Then:

```bash
wrangler secret put ANTHROPIC_API_KEY   # paste your key when asked
wrangler deploy
```

Wrangler prints the worker address, like `https://plate-estimator.your-name.workers.dev`.

### 4. Connect the site to the worker
Edit `config.js` and set `endpoint` to your worker address followed by `/estimate`:

```js
window.PLATE_CONFIG = {
  endpoint: "https://plate-estimator.your-name.workers.dev/estimate"
};
```

Commit the change. GitHub rebuilds the site in a minute or so.

### 5. Try it
Open your site, add a photo of a meal, and press **Estimate calories**.

## Troubleshooting

- **"Photo analysis isn't set up yet"**: `config.js` still has the placeholder address.
- **"This site isn't allowed to use the estimate service"**: `ALLOWED_ORIGINS` doesn't exactly match your site's address. Fix it and run `wrangler deploy` again.
- **"The estimate service isn't set up correctly"**: the `ANTHROPIC_API_KEY` secret is missing.
- **Nothing happens or a network error**: check the endpoint ends in `/estimate` and the worker is deployed.

## Costs and safety

- GitHub Pages and the free Cloudflare Workers plan cost nothing for light use.
- Each estimate is one Claude API call billed to your Anthropic account. The worker limits each visitor to 10 estimates per minute and only accepts requests from your site, but anyone who visits your site can trigger estimates, so keep the spend limit on your key.
- Photos are sent to Claude for analysis and are not stored by this site or the worker.

## Notes

- Estimates from a photo can be off by 20% or more. This is not medical or dietary advice.
- The daily log lives in the visitor's browser (localStorage). Clearing browser data or switching devices starts it over.
