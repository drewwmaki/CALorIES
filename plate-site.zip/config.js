// After you deploy the worker (see README.md), paste its address here.
// It should end in /estimate, for example:
//   https://plate-estimator.your-name.workers.dev/estimate
window.PLATE_CONFIG = {
  endpoint: "https://plate-estimator.YOUR-SUBDOMAIN.workers.dev/estimate"
};
